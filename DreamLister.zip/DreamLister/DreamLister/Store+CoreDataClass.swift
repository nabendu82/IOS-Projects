//
//  Store+CoreDataClass.swift
//  DreamLister
//
//  Created by Nabendu Biswas on 23/10/16.
//  Copyright © 2016 Nabendu Biswas. All rights reserved.
//

import Foundation
import CoreData


public class Store: NSManagedObject {

}
